#ifndef PRINT_H
#define PRINT_H

void print_variable(char *token);

#endif /* PRINT_H */
