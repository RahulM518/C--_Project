#ifndef CONDITION_H
#define CONDITION_H

bool evaluate_condition(int x, char *op, int y);

#endif /* CONDITION_H */
